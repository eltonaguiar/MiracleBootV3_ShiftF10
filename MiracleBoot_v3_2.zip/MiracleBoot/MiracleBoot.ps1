Add-Type -AssemblyName PresentationFramework

# ================= ENV DETECTION =================
function Get-Env {
    if (Test-Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\WinPE' -ErrorAction SilentlyContinue) {
        return 'WinPE'
    }
    if ($env:SystemDrive -eq 'X:') { return 'WinPE' }
    return 'FullOS'
}
$Env = Get-Env

# ================= INTERNET CHECK =================
function Test-Internet {
    try {
        return Test-Connection -ComputerName "www.google.com" -Count 1 -Quiet -ErrorAction Stop
    } catch { return $false }
}

# ================= NETWORK INIT =================
function Init-Internet {
    if (Test-Internet) {
        [System.Windows.MessageBox]::Show("Internet already working.")
        return
    }

    if ($Env -eq 'WinPE') {
        Start-Process wpeinit -Wait
    } else {
        Start-Process cmd.exe -ArgumentList "/c","ipconfig /renew" -Wait
    }

    if (Test-Internet) {
        [System.Windows.MessageBox]::Show("Internet initialized successfully.")
    } else {
        [System.Windows.MessageBox]::Show(
"Internet still not available.

If this is an offline Windows install:
• Ethernet drivers may be missing
• Wi-Fi drivers usually cannot auto-install

Recommended:
• Use wired Ethernet
• Inject LAN drivers offline
• Reboot and retry"
        )
    }
}

# ================= GUI =================
$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
 Title="Miracle Boot v3.2 (CHATGPT edition)"
 Width="520" Height="300" WindowStartupLocation="CenterScreen">
 <Grid>
  <TabControl Margin="10">

   <TabItem Header="Recovery / WinPE (Shift+F10)">
    <StackPanel Margin="20">
     <TextBlock Text="For Windows Setup, WinPE, Hiren, Shift+F10" Margin="0,0,0,10"/>
     <Button Height="40" Name="BtnPE">Initialize Internet (WinPE)</Button>
    </StackPanel>
   </TabItem>

   <TabItem Header="Installed Windows 11">
    <StackPanel Margin="20">
     <TextBlock Text="For already installed Windows 11 (offline recovery)" Margin="0,0,0,10"/>
     <Button Height="40" Name="BtnOS">Initialize Internet (Windows)</Button>
    </StackPanel>
   </TabItem>

  </TabControl>
 </Grid>
</Window>
"@

$Window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader ([xml]$XAML)))

$BtnPE = $Window.FindName("BtnPE")
$BtnOS = $Window.FindName("BtnOS")

$BtnPE.Add_Click({
    if ($Env -ne 'WinPE') {
        [System.Windows.MessageBox]::Show("You are not in WinPE / Shift+F10.")
        return
    }
    Init-Internet
})

$BtnOS.Add_Click({
    if ($Env -ne 'FullOS') {
        [System.Windows.MessageBox]::Show("This option is for full Windows only.")
        return
    }
    Init-Internet
})

$Window.ShowDialog() | Out-Null
