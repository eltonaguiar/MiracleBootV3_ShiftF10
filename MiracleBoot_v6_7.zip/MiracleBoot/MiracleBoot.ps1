Add-Type -AssemblyName PresentationFramework

$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
 Title="Miracle Boot v6.7 (Tiered Recovery + BCD Editor)"
 Width="920" Height="700" WindowStartupLocation="CenterScreen">
 <Grid>
  <TabControl Margin="10">

   <TabItem Header="System Overview">
    <StackPanel Margin="20">
     <TextBlock FontWeight="Bold" Text="Detected Volumes:"/>
     <TextBox Name="TxtVolumes" Height="200" IsReadOnly="True"/>
    </StackPanel>
   </TabItem>

   <TabItem Header="BCD Editor ⚠">
    <StackPanel Margin="20">
     <Button Name="BtnListBCD" Height="35">List Boot Entries</Button>
     <Button Name="BtnRenameBCD" Height="35">Rename Entry using Volume Label</Button>
     <Button Name="BtnForceMenu" Height="35">Force Boot Menu + Timeout</Button>
     <Button Name="BtnSafeMode" Height="35">Enable Safe Mode for Entry</Button>
     <Button Name="BtnBackupBCD" Height="35">Backup BCD Store</Button>
     <TextBox Name="TxtBCD" Height="250" TextWrapping="Wrap" VerticalScrollBarVisibility="Auto"/>
    </StackPanel>
   </TabItem>

  </TabControl>
 </Grid>
</Window>
"@

$Window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader ([xml]$XAML)))

$TxtVolumes = $Window.FindName("TxtVolumes")
$TxtVolumes.Text = (Get-Volume | Select DriveLetter,FileSystemLabel,Size,HealthStatus | Out-String)

$TxtBCD = $Window.FindName("TxtBCD")

$Window.FindName("BtnListBCD").Add_Click({
    $TxtBCD.Text = (& bcdedit /enum all | Out-String)
})

$Window.FindName("BtnRenameBCD").Add_Click({
    $id = Read-Host "Enter Identifier ({current} or GUID)"
    $vol = Read-Host "Enter Volume Label or short name (e.g. MAIN_NVME)"
    $preview = "Windows - $vol"
    $TxtBCD.Text = "Preview Name:`n$preview"
    $confirm = Read-Host "Type YES to apply"
    if ($confirm -eq "YES") {
        bcdedit /set $id description "$preview"
        $TxtBCD.Text += "`nApplied."
    }
})

$Window.FindName("BtnForceMenu").Add_Click({
    $timeout = Read-Host "Enter timeout seconds (e.g. 10)"
    bcdedit /timeout $timeout
    $TxtBCD.Text = "Boot menu forced. Timeout set to $timeout."
})

$Window.FindName("BtnSafeMode").Add_Click({
    $id = Read-Host "Enter Identifier"
    bcdedit /set $id safeboot minimal
    $TxtBCD.Text = "Safe Mode enabled for $id."
})

$Window.FindName("BtnBackupBCD").Add_Click({
    $path = "$env:TEMP\\BCD_Backup.bcd"
    bcdedit /export $path
    $TxtBCD.Text = "BCD backed up to $path"
})

$Window.ShowDialog() | Out-Null
