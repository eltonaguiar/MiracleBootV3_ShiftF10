
Add-Type -AssemblyName PresentationFramework

# Capability matrix
$Caps = @{
  IsWinPE = Test-Path "$env:SystemRoot\System32\wpeinit.exe"
  HasPS = $true
  HasNetsh = Test-Path "$env:SystemRoot\System32\netsh.exe"
  HasMSDT = Test-Path "$env:SystemRoot\System32\msdt.exe"
  HasRegedit = Test-Path "$env:SystemRoot\System32\regedit.exe"
}

# Simple XAML UI (safe subset)
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
 Title="Miracle Boot v6.9"
 Width="900" Height="650" WindowStartupLocation="CenterScreen">
 <Grid Margin="10">
  <TabControl>

   <TabItem Header="Global Tools">
    <StackPanel Margin="10">
     <Button Name="BtnNotepad" Height="32">Open Notepad</Button>
     <Button Name="BtnCmd" Height="32" Margin="0,5,0,0">Open Command Prompt</Button>
     <Button Name="BtnReg" Height="32" Margin="0,5,0,0">Open Registry Editor</Button>
     <Button Name="BtnChar" Height="32" Margin="0,5,0,0">Character Survival Kit</Button>
    </StackPanel>
   </TabItem>

   <TabItem Header="Internet & Network">
    <StackPanel Margin="10">
     <TextBlock Name="TxtNetStatus" FontWeight="Bold"/>
     <Button Name="BtnCheckNet" Height="32" Margin="0,5,0,0">Check Internet</Button>
     <Button Name="BtnFixNet" Height="32" Margin="0,5,0,0">Fix Internet (Windows)</Button>
     <Button Name="BtnInitPE" Height="32" Margin="0,5,0,0">Initialize Internet (WinPE)</Button>
    </StackPanel>
   </TabItem>

   <TabItem Header="Boot / BCD">
    <StackPanel Margin="10">
     <Button Name="BtnListBCD" Height="32">List BCD Entries</Button>
     <Button Name="BtnForceMenu" Height="32" Margin="0,5,0,0">Force Boot Menu + Timeout</Button>
    </StackPanel>
   </TabItem>

  </TabControl>
 </Grid>
</Window>
"@

$Win = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $XAML))

# Wire actions
$Win.FindName("BtnNotepad").Add_Click({ Start-Process notepad })
$Win.FindName("BtnCmd").Add_Click({ Start-Process cmd })
$Win.FindName("BtnReg").Add_Click({
  if ($Caps.HasRegedit) { Start-Process regedit } else { [System.Windows.MessageBox]::Show("regedit not available") }
})
$Win.FindName("BtnChar").Add_Click({
  $p="$env:TEMP\Symbols.txt"
  "@ \ / : | # $ % * _" | Out-File $p -Encoding utf8
  Start-Process notepad $p
})

function Test-Internet {
  if (Test-Connection 8.8.8.8 -Count 1 -Quiet) { return $true }
  return $false
}

$Win.FindName("BtnCheckNet").Add_Click({
  if (Test-Internet) { $Win.FindName("TxtNetStatus").Text="Online" }
  else { $Win.FindName("TxtNetStatus").Text="Offline" }
})

$Win.FindName("BtnFixNet").Add_Click({
  if (-not $Caps.IsWinPE) {
    ipconfig /release | Out-Null
    ipconfig /renew | Out-Null
    netsh winsock reset | Out-Null
    netsh int ip reset | Out-Null
    Start-Process "ms-settings:network"
  } else {
    [System.Windows.MessageBox]::Show("Windows-only feature")
  }
})

$Win.FindName("BtnInitPE").Add_Click({
  if ($Caps.IsWinPE -and (Test-Path "$env:SystemRoot\System32\wpeinit.exe")) {
    Start-Process "$env:SystemRoot\System32\wpeinit.exe" -Wait
  } else {
    [System.Windows.MessageBox]::Show("WinPE-only feature")
  }
})

$Win.FindName("BtnListBCD").Add_Click({
  $out = bcdedit /enum all | Out-String
  [System.Windows.MessageBox]::Show($out.Substring(0,[Math]::Min(2000,$out.Length)))
})

$Win.FindName("BtnForceMenu").Add_Click({
  bcdedit /timeout 10
  [System.Windows.MessageBox]::Show("Boot menu timeout set to 10s")
})

$Win.ShowDialog() | Out-Null
