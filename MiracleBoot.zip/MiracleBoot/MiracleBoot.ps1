Add-Type -AssemblyName PresentationFramework

function Get-Env {
    if (Test-Path 'HKLM:\Software\Microsoft\Windows NT\CurrentVersion\WinPE' -ErrorAction SilentlyContinue) {
        return 'WinPE'
    }
    if ($env:SystemDrive -eq 'X:') { return 'WinPE' }
    return 'FullOS'
}

$Env = Get-Env
$Base = if ($Env -eq 'WinPE') { 'X:\MiracleBoot' } else { Join-Path $env:TEMP 'MiracleBoot' }
$Logs = Join-Path $Base 'Logs'
New-Item -ItemType Directory -Force -Path $Logs | Out-Null

$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
 Title="Miracle Boot (CHATGPT edition)"
 Width="420" Height="220" WindowStartupLocation="CenterScreen">
 <StackPanel Margin="20">
   <TextBlock Text="Environment: $Env" Margin="0,0,0,10"/>
   <Button Name="Net" Height="40" Margin="0,0,0,10">Initialize Internet</Button>
   <Button Name="Exit" Height="40">Exit</Button>
 </StackPanel>
</Window>
"@

$Window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader ([xml]$XAML)))
$Net = $Window.FindName('Net')
$Exit = $Window.FindName('Exit')

$Net.Add_Click({ Start-Process wpeinit -Wait })
$Exit.Add_Click({ $Window.Close() })

$Window.ShowDialog() | Out-Null
