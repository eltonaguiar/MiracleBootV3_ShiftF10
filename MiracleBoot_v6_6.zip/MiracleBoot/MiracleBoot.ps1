Add-Type -AssemblyName PresentationFramework

$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
 Title="Miracle Boot v6.6 (Survival + Deep Recovery)"
 Width="880" Height="680" WindowStartupLocation="CenterScreen">
 <Grid>
  <TabControl Margin="10">

   <TabItem Header="Emergency Tools">
    <StackPanel Margin="20">

     <Button Height="40" Name="BtnKeyboard" Background="DarkSlateBlue" Foreground="White">
      Switch Keyboard Layout (WinPE)
     </Button>
     <TextBlock Foreground="Gray" Margin="0,5,0,10">
      Fix broken symbols like @ \ # in Shift+F10.
     </TextBlock>

     <Button Height="40" Name="BtnCharPalette">
      Open Character Survival Kit
     </Button>
     <TextBlock Foreground="Gray" Margin="0,5,0,10">
      Copy-paste critical characters and paths.
     </TextBlock>

     <Separator Margin="0,10,0,10"/>

     <Button Height="40" Name="BtnFileMan">
      Open File Manager / Notepad
     </Button>

     <Button Height="40" Margin="0,5,0,0" Name="BtnBootRepair"
      Background="DarkRed" Foreground="White">
      AUTO-REPAIR BOOT (EFI/GPT)
     </Button>

     <Separator Margin="0,10,0,10"/>

     <Button Height="40" Name="BtnISOCheck" Background="DarkGreen" Foreground="White">
      Check Recovery ISO Compatibility
     </Button>

    </StackPanel>
   </TabItem>

   <TabItem Header="Drivers & Hardware">
    <StackPanel Margin="20">
     <Button Height="40" Name="BtnSmartDriver">
      Smart Driver Discovery (Local)
     </Button>
    </StackPanel>
   </TabItem>

  </TabControl>
 </Grid>
</Window>
"@

$Window = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader ([xml]$XAML)))

function Run-Task ($task) {
    Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$PSScriptRoot\WinRepairTool.ps1`" -Task $task" -Wait
}

$Window.FindName("BtnKeyboard").Add_Click({ Run-Task "Keyboard" })
$Window.FindName("BtnCharPalette").Add_Click({ Run-Task "CharPalette" })
$Window.FindName("BtnFileMan").Add_Click({ Run-Task "FileManager" })
$Window.FindName("BtnBootRepair").Add_Click({ Run-Task "BootRepair" })
$Window.FindName("BtnISOCheck").Add_Click({ Run-Task "ISOCheck" })
$Window.FindName("BtnSmartDriver").Add_Click({ Run-Task "SmartDriver" })

$Window.ShowDialog() | Out-Null
