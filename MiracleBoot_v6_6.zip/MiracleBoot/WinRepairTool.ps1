param([string]$Task = "Main")

function Show-Header {
    Clear-Host
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host " MIRACLE BOOT - SURVIVAL / DEEP RECOVERY ENGINE v6.6      " -ForegroundColor White -BackgroundColor Blue
    Write-Host " EFI / VMD / NVMe / WinRE / Keyboard Safe                " -ForegroundColor Yellow
    Write-Host "==========================================================`n"
}

function Get-TargetDrive {
    Get-Volume | Select DriveLetter, FileSystemLabel, Size, HealthStatus | Format-Table -AutoSize
    Read-Host "Enter Windows drive letter"
}

function Invoke-KeyboardSwitch {
    Show-Header
    Write-Host "0409 = English (US)"
    Write-Host "0809 = English (UK)"
    $id = Read-Host "Layout ID (default 0409)"
    if ($id -eq "") { $id = "0409" }
    wpeutil SetKeyboardLayout $id
    Pause
}

function Invoke-CharPalette {
    Show-Header
    $path = "X:\Symbols.txt"
    "@ \ / : | # $ % * _" | Out-File $path -Encoding utf8
    Start-Process notepad.exe $path
    Pause
}

function Invoke-SmartDriverDiscovery {
    Show-Header
    $missing = Get-PnpDevice | Where-Object { $_.ConfigManagerErrorCode -ne 0 -and $_.HardwareID }
    foreach ($dev in $missing) {
        Write-Host "Device: $($dev.FriendlyName)"
    }
    Pause
}

function Invoke-ISOCheck {
    Show-Header
    $win = Get-TargetDrive
    $reg = "$($win):\Windows\System32\config\SOFTWARE"
    if (!(Test-Path $reg)) { Pause; return }
    reg load HKLM\OFFSOFT $reg | Out-Null
    $cv = Get-ItemProperty "HKLM:\OFFSOFT\Microsoft\Windows NT\CurrentVersion"
    reg unload HKLM\OFFSOFT | Out-Null
    Write-Host "Installed: $($cv.EditionID) Build $($cv.CurrentBuild)"
    Get-Volume | ForEach-Object {
        $wim = "$($_.DriveLetter):\sources\install.wim"
        if (Test-Path $wim) {
            Write-Host "Media on $($_.DriveLetter):"
            dism /Get-WimInfo /WimFile:$wim | Select-String "Edition|Architecture|Version"
        }
    }
    Pause
}

function Invoke-FileManager {
    Start-Process notepad.exe
    try { (New-Object -ComObject Shell.Application).BrowseForFolder(0,"Explore",0,17) } catch {}
    Pause
}

function Invoke-BootRepair {
    Show-Header
    $efi = Get-Partition | Where-Object { $_.GptType -eq "{c12a7328-f81f-11d2-ba4b-00a0c93ec93b}" }
    if (!$efi) { Pause; return }
    if (!$efi.DriveLetter) { $efi | Set-Partition -NewDriveLetter S }
    $win = Get-TargetDrive
    bcdboot "$($win):\Windows" /s "$($efi.DriveLetter):" /f UEFI
    Pause
}

switch ($Task) {
    "Keyboard"     { Invoke-KeyboardSwitch }
    "CharPalette"  { Invoke-CharPalette }
    "FileManager"  { Invoke-FileManager }
    "BootRepair"   { Invoke-BootRepair }
    "SmartDriver"  { Invoke-SmartDriverDiscovery }
    "ISOCheck"     { Invoke-ISOCheck }
}
